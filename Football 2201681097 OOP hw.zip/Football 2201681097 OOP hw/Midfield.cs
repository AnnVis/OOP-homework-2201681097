﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Football_2201681097_OOP_hw
{
    public class Midfield:Football_player
    {
        public Midfield(string name, int age, int number, double height)
            :base(name, age, number, height)
        {

        }
    }
}
