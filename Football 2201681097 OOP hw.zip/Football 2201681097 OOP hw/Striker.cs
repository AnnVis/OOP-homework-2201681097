﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Football_2201681097_OOP_hw
{
    public class Striker:Football_player
    {
        public Striker(string name, int age, int number, double height)
            :base(name, age, number, height)
        {

        }
    }
}
